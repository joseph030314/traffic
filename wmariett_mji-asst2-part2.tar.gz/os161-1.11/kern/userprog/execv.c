
#include <types.h>
#include <lib.h>
#include <syscall.h>
#include <process.h>
#include <addrspace.h>
#include <machine/trapframe.h>
#include <vfs.h>
#include <curthread.h>
#include <vm.h>
#include <test.h>
#include <kern/errno.h>
#include <vnode.h>
#include <kern/unistd.h>
#include <kern/limits.h>


//helper function to copy in the args
static int copyin_args_withAlign(char** kernelArgs, char** userArgs, int *numArgs)
{
	
	
	//make sure user args arent null
	if(userArgs == NULL)
	{
		return EFAULT;
	}
	
	int error;

	//copy in the args
	char **kargs = NULL; 
	kargs =	kmalloc(sizeof(userArgs));
	if(kargs == NULL)
	{
		return ENOMEM;
	}
	
	
	error = copyin((userptr_t)userArgs, kargs, sizeof(userArgs));
	if(error)
	{
		return error;
	}
	

	//count the number of args
	int nArgs = 0;
	int i = 0;
	while(1)
	{
		if(kargs[i] == NULL)
		{
			break;
		}

		nArgs += 1;
	}
	
	*numArgs = nArgs;

	
	kernelArgs = kmalloc(sizeof(userArgs));
	if(kernelArgs == NULL)
	{
		return ENOMEM;
	}	

	
	//doing this so it compiles without errors and gives something back to sys_execv
	error = copyin((userptr_t)userArgs, kernelArgs, sizeof(userArgs));
	if(error)
	{
		return error;
	}


	return 0;
}

int sys_execv(char *program, char **args)
{


	assert(curthread != NULL);
	assert(curthread->t_proc != NULL);

	//copy args from userspace into kernel buffer
	char programName[128]; //this is the max size of a progam name in menu.c so it will prolly work here
	int error;

	error = copyinstr((userptr_t)program, programName, sizeof(programName), NULL);
	if(error)
	{
		return error;
	}


	int numArgs = 0;
	char **programArgs = NULL;
	error = copyin_args_withAlign(programArgs, args, &numArgs);
	//error = copyin(args, programArgs, sizeof(args)); 
	if(error)
	{
		return error;
	}


	//open executable
	struct vnode *v;
	vaddr_t entrypoint, stackptr;

	error = vfs_open(programName, O_RDONLY, &v);
	if(error)
	{
		return error;
	}


	//create new address space
	assert(curthread->t_vmspace == NULL);

	curthread->t_vmspace = as_create();
	if(curthread->t_vmspace == NULL)
	{
		vfs_close(v);
		return ENOMEM;
	}	
	
	as_activate(curthread->t_vmspace);
	

	//load the elf into it
	error = load_elf(v, &entrypoint);
	if(error)
	{
		vfs_close(v);
		return error;
	}

	vfs_close(v);


	//allocate a stack on the ne address space using as_define_stack
	error = as_define_stack(curthread->t_vmspace, &stackptr);
	if(error)
	{
		return error;
	}


	//copy args from kernel buffer into user stack
	error = copyout(programArgs, (userptr_t)stackptr, sizeof(programArgs));
	if(error)
	{
		return error;
	}	

	//return to usermode by calling md_usermode
	md_usermode(numArgs,(userptr_t) programArgs, stackptr, entrypoint);
	





	return EINVAL;
}




