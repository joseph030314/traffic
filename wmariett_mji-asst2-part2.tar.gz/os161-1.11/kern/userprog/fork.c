

#include <types.h>
#include <lib.h>
#include <process.h>
#include <curthread.h>
#include <machine/trapframe.h>
#include <synch.h>
#include <syscall.h>
#include <addrspace.h>
#include <thread.h>

//have to declare for some reason
static void fork_entry(void * ptr, unsigned long num);


//used to pass parameters to child thread
struct forkArgs
{
	struct process *childProcess;
	struct trapframe *tf;
	struct addrspace *source;
};



/*the fork system call*/
int sys_fork(struct trapframe *tf, int *retval)
{
	
	struct forkArgs *args= NULL;
	struct trapframe *childTf = NULL;
	struct process *childProc = NULL;

		
	//make sure everything isnt null
	assert(curthread != NULL);
	assert(curthread->t_proc != NULL);
	assert(tf != NULL);
	

	//precreate child process
	childProc = process_create();
	if(childProc == NULL)
	{
		return -1;
	}


	//setup childprocess and store pid for returning
	int pid = childProc->pid;
	childProc->parent = curthread->t_proc;


	//copy the trapframe
	childTf = kmalloc(sizeof(struct trapframe));
	if(childTf == NULL)
	{
		return -1;
	}

	memcpy(childTf, tf, sizeof(struct trapframe));

	


	//make args struct to hold trapeframe, addressspace, and parent process for passing to child
	args = kmalloc(sizeof(struct forkArgs));
	if(args == NULL)
	{
		return -1;
	}
	
	

	//copy the address space into args
	int error;
	error = as_copy(curthread->t_vmspace, &args->source);
	if(error)
	{
		kfree(args->tf);
		kfree(args);
		return error;
	}
	//addrspace successfully copied
	
	//put other things into args
	args->tf = childTf;
	args->childProcess = childProc;


	
	//start the child thread
	error = thread_fork(curthread->t_name, args, 0 , fork_entry, NULL);
	if(error)
	{
		//thread failed for some reason
		as_destroy(args->source);
		process_destroy(childProc);
		kfree(args->tf);
		kfree(args);
		
		return error;
	}
	
	
	


	*retval = pid;
	return 0;
}

//entry point for forks
static void fork_entry(void *ptr, unsigned long num)
{
	//unused parameter
	(void) num;


	struct forkArgs *args = NULL;
	struct trapframe childTf;

	//get the args passed through by thread_fork
	args = ptr;
	


	//give thread its process
	curthread->t_proc = args->childProcess;

	
	//set various counters in trapframe described in slides
	//make child fork look successful
	args->tf->tf_v0 = 0;
	args->tf->tf_a3 = 0;
	args->tf->tf_epc += 4; //inc epc by 4 to avoid child calling fork


	//load passed in address space into child threads addres space and activate it
	curthread->t_vmspace = args->source;
	as_activate(curthread->t_vmspace);

	
	//copy the modified trapframe from kernel heal to stack
	memcpy(&childTf, args->tf, sizeof(struct trapframe));


	//return to usermod from child process
	mips_usermode(&childTf);

}
















