
#include <types.h>
#include <lib.h>
#include <thread.h>
#include <curthread.h>
#include <syscall.h>
#include <process.h>

void sys_exit(int code)
{
	
	assert(curthread != NULL);
	assert(curthread->t_proc != NULL);

	//get the process
	struct process *proc = curthread->t_proc;

	//set it to dead and set return value
	proc->isDead = 1;
	proc->returnValue = code;

	//signal people waiting on the exit
	V(proc->interestSem);


	//exit thread
	thread_exit();
	
}


