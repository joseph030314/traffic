
#include <types.h>
#include <lib.h>
#include <thread.h>
#include <curthread.h>
#include <process.h>
#include <synch.h>




int sys_waitpid(pid_t pid, userptr_t status, int options)
{

	//get the process to be waiting for
	//sign up for its semaphore to wait for it to exit
	
	(void)options;

	//get the wanted process
	struct process *wantedProc = NULL;
	wantedProc = process_getProc(pid);
	if(wantedProc == NULL)
	{
		//couldnt find process
		return -1;
	}

	//wait for it to die
	P(wantedProc->interestSem);

	//make sure its dead
	assert(wantedProc->isDead == 1);

	//set the return value which is a userptr so must copy it out
	int error = copyout(&wantedProc->returnValue, status, sizeof(int));
	if(error)
	{
		return error;
	}

	//save the pid
	int procPid = pid;

	//destroy the process
	process_destroy(wantedProc);

	//return the process id
	return procPid;
}






