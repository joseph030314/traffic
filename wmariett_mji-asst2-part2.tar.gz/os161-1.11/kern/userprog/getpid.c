#include <types.h>
#include <lib.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>


int sys_getpid(int *retval)
{
	
	assert(curthread != NULL);
	assert(curthread->t_proc != NULL);

	*retval = curthread->t_proc->pid;
	
	return 0;
}
