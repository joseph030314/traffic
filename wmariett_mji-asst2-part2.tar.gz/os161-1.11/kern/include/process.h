#ifndef PROCESS_H
#define PROCESS_H



#include <types.h>
#include <synch.h>


#define MAX_PROCESSES 128
#define PT_RESERVED_SPOT 0xbeefbabe /*frogger is a cool game*/

//process structure
struct process
{
	pid_t pid; /*pid of the process*/
	int isDead; /*0 for alive, 1 for dead*/
	int returnValue; /*return value of the process*/
	struct process *parent; /*parent process*/
	struct semaphore *interestSem; /*used by exit and waitpid to show interest in exit status*/
};


//global variables
extern struct process *processTable[MAX_PROCESSES];
extern struct lock *processTableLock;



//functions

//creates a process and stores it in a pointer
struct process * process_create();

//destroys a process
void process_destroy(struct process *proc);

//init processTable array
void process_init_system();

//returns a process from the processTable given a pid
struct process * process_getProc(int pid);

#endif
