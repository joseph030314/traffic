

#include <types.h>
#include <lib.h>
#include <kern/errno.h>
#include <process.h>
#include <synch.h>


struct process *processTable[MAX_PROCESSES];
struct lock *processTableLock;



/*Returns a process from the process table given its pid*/
struct process * process_getProc(int pid)
{
	struct process *proc = NULL;

	if(pid >= MAX_PROCESSES)
	{
		return NULL;
	}

	if(pid < 0)
	{
		return NULL;
	}




	lock_acquire(processTableLock);


	if(processTable[pid] != NULL && processTable[pid] != PT_RESERVED_SPOT)
	{
		proc = processTable[pid];
	}


	lock_release(processTableLock);
	

	
	return proc;	


}






void process_init_system()
{
	//init processTable array
	int i = 0;
	for(i = 0; i < MAX_PROCESSES; i++)
	{
		processTable[i] = NULL;
	}



	//create the lock for the process table
	processTableLock = lock_create("processTableLock");
	if(processTableLock == NULL)
	{
		lock_destroy(processTableLock);
		kprintf("Couldn't create process table lock");
		return;
	}
	
	

}


/*reserves the spot in the process table*/
static void process_reserve_ptSpot(int spot, pid_t *pid)
{
	//make sure the spot is still null
	assert(processTable[spot] == NULL);
	
	//reserve the spot
	processTable[spot] = (void *)PT_RESERVED_SPOT;
	*pid = spot;
}



/*finds the first available pid and reserves it*/
static int process_get_nextPid(pid_t *pid)
{
	
	if(processTableLock == NULL)
	{
		processTableLock = lock_create("processTableLock");
	}


	//lock for safety
	lock_acquire(processTableLock);

	//loop through processTable find the first NULL entry. That location will be the pid
	int i = 0;
	for(i = 0; i < MAX_PROCESSES; i++)
	{
		if(processTable[i] == NULL)
		{
			process_reserve_ptSpot(i, pid);
			lock_release(processTableLock);
			return 0;
		}
	}	
	
	
	lock_release(processTableLock);
	return 1;
}


/*Release the spot at location pid */
static void process_release_ptSpot(pid_t pid)
{
	//acquire lock for safety
	lock_acquire(processTableLock);
	
	processTable[pid] = NULL;	
	
	//unlock
	lock_release(processTableLock);

}


/*adds the process to the process table at location pid*/
static void process_add_to_processTable(struct process *proc, int spot)
{
	//get lock for safety
	lock_acquire(processTableLock);

	assert(processTable[spot] == (void *)PT_RESERVED_SPOT);
	processTable[spot] = proc;

	//unlock
	lock_release(processTableLock);


}


/*Creates a process struct and returns it*/
struct process *  process_create()
{
	struct process *newProc = NULL;
	int error = 0;
	pid_t pid;

	error = process_get_nextPid(&pid);
	if(error){return NULL;}
	
	newProc = kmalloc(sizeof(struct process));
	if(newProc == NULL)
	{
		kprintf("Failed to malloc new process.");
		process_release_ptSpot(pid);
		return NULL;
	}

	struct semaphore *sem = NULL;
        sem = sem_create("interestSem", 0);
	if(sem == NULL)
	{
		kprintf("Failed to malloc sem in new process.");
		process_release_ptSpot(pid);
		kfree(newProc);
		return NULL;
	}

	newProc->pid = pid;
	newProc->isDead = 0;
	newProc->returnValue = 0;	
	newProc->parent = NULL;	
	newProc->interestSem = sem;


	//add to process table
	process_add_to_processTable(newProc, pid);
	




	return newProc;



}

/*frees the process and releases the pid so others may use it*/
void process_destroy(struct process *proc)
{
	pid_t pid = proc->pid;

	sem_destroy(proc->interestSem);
	kfree(proc);

	process_release_ptSpot(pid);
}



