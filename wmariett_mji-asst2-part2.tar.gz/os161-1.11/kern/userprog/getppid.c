#include <types.h>
#include <lib.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>

int sys_getppid(int *retval)
{
	
	assert(curthread != NULL);
	assert(curthread->t_proc != NULL);
	
	if(curthread->t_proc->parent == NULL)
	{
		*retval = -1;
	}

	else
	{
		*retval = curthread->t_proc->parent->pid;
	}


	return 0;
}
